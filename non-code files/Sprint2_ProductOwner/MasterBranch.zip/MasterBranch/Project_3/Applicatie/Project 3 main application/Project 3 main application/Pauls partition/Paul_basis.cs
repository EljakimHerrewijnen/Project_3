﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Project_3_main_application.Marcels_partition;

/*  Deze file is van: "Paul de Keijzer"
*
*/

namespace Project_3_main_application
{
    class Paul_basis
    {
        ////static int count = 0;
        public void LoadContent(Globalvars GlobalVars, Game1 game1)
        {
            //Hier kan je al je plaatjes enzo laden
            //textDict.Add("test2", game1.Content.Load<Texture2D>("itshim.jpg"));
        }


        public void Initialize(Globalvars GlobalVars)
        {
            //Hier kan je initializatie doen
        }

        public void unloadContent()
        {
            //Hier kan je dingen ontladen
        }

        public void Update(GameTime gameTime)
        {
            //Hier moet je update logica komen
        }

        public void Draw(SpriteBatch spriteBatch, Globalvars GlobalVars)
        {
            //if (count < 100) { spriteBatch.Draw(textDict["test2"], new Vector2(100, 0), Color.White); }
            //else if (count < 200) { spriteBatch.Draw(textDict["test2"], new Vector2(200, 0), Color.White); }
            //else if ( count < 300) { spriteBatch.Draw(textDict["test2"], new Vector2(300, 0), Color.White); }
            //else if (count < 400) { spriteBatch.Draw(textDict["test2"], new Vector2(400, 0), Color.White); }
            //else if (count < 500) { spriteBatch.Draw(textDict["test2"], new Vector2(500, 0), Color.White); }
            //else if (count < 600) { spriteBatch.Draw(textDict["test2"], new Vector2(500, 100), Color.White); }
            //else if (count < 700) { spriteBatch.Draw(textDict["test2"], new Vector2(500, 200), Color.White); }
            //else if (count < 800) { spriteBatch.Draw(textDict["test2"], new Vector2(500, 300), Color.White); }
            //else if (count < 900) { spriteBatch.Draw(textDict["test2"], new Vector2(500, 300), Color.White); }
            //else if (count < 1000) { spriteBatch.Draw(textDict["test2"], new Vector2(400, 300), Color.White); }
            //else if (count < 1100) { spriteBatch.Draw(textDict["test2"], new Vector2(300, 300), Color.White); }
            //else if (count < 1200) { spriteBatch.Draw(textDict["test2"], new Vector2(200, 300), Color.White); }
            //else if (count < 1300) { spriteBatch.Draw(textDict["test2"], new Vector2(100, 300), Color.White); }
            //else if (count < 1400) { spriteBatch.Draw(textDict["test2"], new Vector2(100, 0), Color.White); }
            //else if (count < 1500) { spriteBatch.Draw(textDict["test2"], new Vector2(500, 300), Color.White); }
            //else if (count < 1600) { spriteBatch.Draw(textDict["test2"], new Vector2(100, 300), Color.White); }
            //else if (count < 1700) { spriteBatch.Draw(textDict["test2"], new Vector2(300, 150), Color.White); }
            //else { spriteBatch.Draw(textDict["test2"], new Vector2(0, 400), Color.White); }

            //if (count == 1700) { count = 0; }
            //count += 10;
        }
    }
}
