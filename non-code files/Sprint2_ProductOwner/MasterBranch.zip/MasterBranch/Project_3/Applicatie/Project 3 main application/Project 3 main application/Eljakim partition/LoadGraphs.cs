﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_3_main_application.Eljakim_partition
{
    public partial class LoadGraphs : Form
    {
        public LoadGraphs()
        {
            InitializeComponent();
        }
    }
}
