﻿using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_3_main_application.Marcels_partition
{
    class Globalvars
    {
        public Dictionary<string, Texture2D> textDict = new Dictionary<string, Texture2D>();
        public Dictionary<string, SpriteFont> fontDict = new Dictionary<string, SpriteFont>();

        public Globalvars()
        {

        }
    }
}
